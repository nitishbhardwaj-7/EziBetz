# Design System Document: High-Octane Premium

## 1. Overview & Creative North Star: "The Neon Velocity"
The Creative North Star for this design system is **Neon Velocity**. We are moving away from the "cluttered casino" trope and toward a high-end, editorial sports-luxe aesthetic. The goal is to capture the adrenaline of gaming through deep tonal immersion and electric highlights.

This system breaks the traditional "box-and-line" template by utilizing **intentional asymmetry** and **tonal depth**. Instead of rigid grids, we use overlapping elements and "floating" glass modules to create a sense of movement. We prioritize breathing room (whitespace) to allow the "Glossy" elements to truly shine, ensuring the user feels they are in a premium VIP lounge rather than a chaotic arcade.

---

## 2. Colors & Surface Philosophy

### The Palette
- **Primary (Electric Violet):** `#c59aff` (Primary) to `#9547f7` (Primary Dim). Use these for high-action touchpoints.
- **Secondary (Cyan Spark):** `#00f4fe`. Reserved for "Win" states, live indicators, and secondary calls to action.
- **Tertiary (Plasma Pink):** `#ff59e3`. Used sparingly for jackpots or urgent notifications.
- **Neutral/Background:** `#110a1e` (Surface). A deep, "midnight" purple that provides the canvas for our neon accents.

### The "No-Line" Rule
**Prohibit 1px solid borders for sectioning.** Physical boundaries are a relic of low-resolution design. In this system, containment is defined through:
1.  **Background Color Shifts:** Placing a `surface-container-high` (`#241b35`) card against a `surface` (`#110a1e`) background.
2.  **Tonal Transitions:** Using subtle gradients to guide the eye.

### Surface Hierarchy & Nesting
Treat the UI as layered sheets of obsidian and frosted glass.
- **Base Level:** `surface` (#110a1e).
- **Secondary Level:** `surface-container-low` (#170f25) for grouped content sections.
- **Interactive Level:** `surface-container-highest` (#2b203e) for cards and betting modules.
- **Floating Level:** Semi-transparent versions of `surface-bright` with a 20px backdrop blur (Glassmorphism).

### The "Glass & Gradient" Rule
To achieve "High-Energy," use the **Signature Glow**. Main CTAs must use a linear gradient from `primary` (#c59aff) to `primary-dim` (#9547f7) at a 135-degree angle. This creates a "liquid light" effect that flat colors cannot replicate.

---

## 3. Typography: The Editorial Edge

We use a high-contrast pairing to balance "Sporty" energy with "Premium" readability.

*   **Display & Headlines (Plus Jakarta Sans):** A modern, geometric sans-serif with a wide stance. It feels fast and authoritative.
    *   *Usage:* Use `display-lg` (3.5rem) for big wins and `headline-md` (1.75rem) for game titles.
*   **Body & Titles (Manrope):** A highly legible, technical sans-serif that ensures clarity in complex betting data.
    *   *Usage:* Use `body-md` (0.875rem) for odds and terms.

**Typographic Hierarchy:**
- **The Power Scale:** Large-scale `display` type should be `on-surface` (#ede0fd) with a slight `primary` text-shadow to "lift" it off the dark background.
- **Secondary Info:** Labels and helper text must use `on-surface-variant` (#b2a6c1) to maintain focus on the primary action.

---

## 4. Elevation & Depth: Tonal Layering

### The Layering Principle
Do not use shadows to define a box; use shadows to define **height**.
- **Static Cards:** No shadow. Differentiation is achieved via `surface-container-high` (#241b35).
- **Active/Hovered Cards:** Transition to `surface-bright` (#312646) and apply an **Ambient Shadow**.

### Ambient Shadows
Shadows must be invisible but felt.
- **Value:** `0px 20px 40px rgba(0, 0, 0, 0.4)`. 
- **The Ghost Border:** If a boundary is required for accessibility, use `outline-variant` (#4c445b) at **15% opacity**.

### Glassmorphism
For "Balance Displays" and "Live Betting Slips," use a background of `surface-container` (#1e152e) at 70% opacity with a `blur(12px)`. This keeps the user grounded in the game while they manage their funds.

---

## 5. Signature Components

### Glossy Buttons (Primary)
- **Visuals:** Gradient of `primary` to `primary-dim`.
- **Gloss Overlay:** A subtle, 1px white-to-transparent top-inner-shadow (inset) to mimic a light-reflecting glass edge.
- **Rounding:** `full` (9999px) for a sleek, ergonomic feel.
- **Text:** `on-primary` (#420082), Uppercase, Bold.

### Game Cards
- **Construction:** Use `surface-container-highest` (#2b203e). 
- **Rule:** **No Dividers.** Separate the game image from the game stats using a `6` (1.5rem) spacing gap.
- **Corner Radius:** `xl` (1.5rem) for the outer container; `lg` (1rem) for nested images.

### Balance Displays
- **Style:** Editorial-inspired. Large `headline-lg` value in `secondary` (#00f4fe). 
- **Context:** Place on a "Glass" module that floats at the top of the viewport during gameplay.

### Interactive Betting Controls
- **Stepper/Slider:** Use `secondary` (#00f4fe) for the active track.
- **Quick-Bet Chips:** `surface-variant` (#2b203e) backgrounds. On selection, they "ignite" into the `primary` gradient.
- **Input Fields:** Use `surface-container-lowest` (#000000) with a `primary` "Ghost Border" (20% opacity) that becomes 100% opaque on focus.

---

## 6. Do’s and Don’ts

### Do:
- **Use Asymmetry:** Offset your headlines. Don't center-align everything; let the typography lead the eye across the screen.
- **Embrace the Dark:** Keep 90% of the UI in the `surface` and `surface-container` tiers to make the `primary` accents pop.
- **Use the Spacing Scale:** Stick strictly to the increments of `4` (1rem) and `8` (2rem) to maintain rhythmic consistency.

### Don't:
- **No Pure White Backgrounds:** "Clean white" in the prompt refers to typography and accents. A white background would kill the "high-energy" neon vibe. Use `on-background` (#ede0fd) for "white" elements.
- **No Dividers:** If you feel the need to add a line, add `1.5rem` of whitespace instead.
- **No Sharp Corners:** Avoid `none` or `sm` roundedness. This system is about "Velocity," which requires smooth, aerodynamic curves (`lg` to `xl`).